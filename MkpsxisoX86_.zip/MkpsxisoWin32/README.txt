ENG: it is MANDATORY to copy and paste ALL files from this folder for mkpsxiso win32 to work correctly.
for example: if you extract only the exe file, mkpsxiso will NOT work on your Windows x86 device on x64 only.



PT-BR: é OBRIGATÓRIO que você copie e cole TODOS os arquivos nessa pasta para o mkpsxiso para o windows 32-bits funcionar perfeitamente
ex: se você copiar e colar apenas o arquivo exe, o mkpsxiso NÃO irá funcionar no seu dispositivo 32 Bits apenas nos de 64 Bits.


Credits: this tool was NOT made by me. is made by Lameguy.